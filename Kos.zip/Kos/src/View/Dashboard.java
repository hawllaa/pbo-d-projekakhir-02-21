package View;
import Controller.controller.ControllerDashboard;
import Model.Data.*;
import java.awt.Color;
import javax.swing.*;
import javax.swing.table.*;

public class Dashboard extends javax.swing.JFrame {

    public Dashboard() {
        initComponents();
        ControllerDashboard controller;
        controller = new ControllerDashboard(this);
        controller.showAllKos();
        hideColumn(TableKos,0);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        TableKos.getTableHeader().setBackground(Color.WHITE); 
        TableKos.getTableHeader().setForeground(Color.BLACK);
        TableKos.setSelectionBackground(new java.awt.Color(255, 255, 204)); 
        TableKos.setSelectionForeground(new java.awt.Color(0, 0, 0)); 

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnCari = new javax.swing.JButton();
        jcbCari = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        btnTambah = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblNAnak = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblNoAnak = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        lblNOrtu = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        lblNoOrtu = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        lblAsal = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableKos = new javax.swing.JTable();
        btnBatal = new javax.swing.JButton();
        lblLogout = new javax.swing.JLabel();
        lblAngkatan = new javax.swing.JTextField();
        lblNoKamar = new javax.swing.JTextField();
        btnTampil = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(249, 213, 236));
        jPanel1.setPreferredSize(new java.awt.Dimension(110, 770));

        btnCari.setBackground(new java.awt.Color(0, 143, 227));
        btnCari.setForeground(new java.awt.Color(255, 255, 255));
        btnCari.setText("Cari");
        btnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCariActionPerformed(evt);
            }
        });

        jcbCari.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" }));

        jLabel10.setText("Cari Kamar");

        btnTambah.setBackground(new java.awt.Color(0, 143, 227));
        btnTambah.setForeground(new java.awt.Color(255, 255, 255));
        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnEdit.setBackground(new java.awt.Color(0, 143, 227));
        btnEdit.setForeground(new java.awt.Color(255, 255, 255));
        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });

        btnHapus.setBackground(new java.awt.Color(0, 143, 227));
        btnHapus.setForeground(new java.awt.Color(255, 255, 255));
        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnTambah, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                    .addComponent(btnEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnHapus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCari, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jcbCari, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jcbCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCari)
                .addGap(396, 396, 396)
                .addComponent(btnTambah)
                .addGap(18, 18, 18)
                .addComponent(btnEdit)
                .addGap(18, 18, 18)
                .addComponent(btnHapus)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(200, 235, 255));

        jLabel1.setFont(new java.awt.Font("Perpetua Titling MT", 1, 36)); // NOI18N
        jLabel1.setText("DATA KOS EISAH");

        jLabel2.setText("Nama");

        jLabel3.setText("No Kamar");

        jLabel4.setText("Angkatan");

        jLabel5.setText("No HP Anak");

        jLabel6.setText("Nama Ortu/Wali");

        jLabel7.setText("No HP Ortu/Wali");

        jLabel9.setText("Asal");

        TableKos.setBackground(new java.awt.Color(255, 221, 243));
        TableKos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        TableKos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TableKos.setGridColor(new java.awt.Color(0, 0, 0));
        TableKos.setSelectionBackground(new java.awt.Color(255, 255, 204));
        TableKos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableKosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableKos);

        btnBatal.setBackground(new java.awt.Color(252, 113, 200));
        btnBatal.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        btnBatal.setForeground(new java.awt.Color(255, 255, 255));
        btnBatal.setText("Batal");
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });

        lblLogout.setFont(new java.awt.Font("Dialog", 0, 36)); // NOI18N
        lblLogout.setText(" ⍈");
        lblLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLogoutMouseClicked(evt);
            }
        });

        lblAngkatan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblAngkatanActionPerformed(evt);
            }
        });

        lblNoKamar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lblNoKamarActionPerformed(evt);
            }
        });

        btnTampil.setBackground(new java.awt.Color(252, 113, 200));
        btnTampil.setFont(new java.awt.Font("Dialog", 1, 11)); // NOI18N
        btnTampil.setForeground(new java.awt.Color(255, 255, 255));
        btnTampil.setText("Tampilkan Data");
        btnTampil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTampilActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(103, 103, 103)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 632, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblAngkatan, javax.swing.GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
                            .addComponent(lblNoAnak)
                            .addComponent(lblNAnak)
                            .addComponent(lblNoKamar))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblNOrtu, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(lblAsal, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                                    .addComponent(lblNoOrtu)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnTampil)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(35, 35, 35))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(232, 232, 232)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(16, 16, 16)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblNAnak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6)
                                .addComponent(lblNOrtu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblNoAnak, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(lblNoOrtu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblAngkatan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9)
                                    .addComponent(lblAsal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4))
                                .addGap(18, 18, 18)
                                .addComponent(lblNoKamar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnTampil, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(95, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 779, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLogoutMouseClicked
        this.dispose();
        HalamanUtama halamanUtamaframe = new HalamanUtama();
        halamanUtamaframe.setVisible(true);
    }//GEN-LAST:event_lblLogoutMouseClicked

    private void lblAngkatanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblAngkatanActionPerformed
       
    }//GEN-LAST:event_lblAngkatanActionPerformed

    private void hideColumn(JTable table, int colIndex) {
        TableColumn column = table.getColumnModel().getColumn(colIndex);
        column.setMinWidth(0);
        column.setMaxWidth(0);
        column.setPreferredWidth(0);
        column.setWidth(0);
        column.setResizable(false);
    }
    
    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        String noKamarInput = lblNoKamar.getText(); // Ambil input dari JTextField
        try {
            int noKamar = Integer.parseInt(noKamarInput); // Coba konversi ke integer
        
            if (noKamar < 1 || noKamar > 30) {
                throw new NumberFormatException("Nomor kamar harus antara 1 dan 30.");
            }
        
            ControllerDashboard controller = new ControllerDashboard(this);
            controller.insertKos();
            controller.showAllKos();
            hideColumn(TableKos, 0);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Input tidak valid: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_btnTambahActionPerformed

    private void TableKosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableKosMouseClicked
        Integer baris = TableKos.getSelectedRow();
        lblNAnak.setText(TableKos.getValueAt(baris, 1).toString());
        lblNoAnak.setText(TableKos.getValueAt(baris, 2).toString());
        lblAngkatan.setText(TableKos.getValueAt(baris, 3).toString());
        lblNoKamar.setText(TableKos.getValueAt(baris, 4).toString());
        lblNOrtu.setText(TableKos.getValueAt(baris, 5).toString());
        lblNoOrtu.setText(TableKos.getValueAt(baris, 6).toString());
        lblAsal.setText(TableKos.getValueAt(baris, 7).toString());

    }//GEN-LAST:event_TableKosMouseClicked

    private void lblNoKamarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lblNoKamarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lblNoKamarActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
        int baris = TableKos.getSelectedRow();
            ControllerDashboard controller;
            controller = new ControllerDashboard(this);
            if (baris != -1) {
                int IdData = Integer.parseInt(TableKos.getValueAt(baris, 0).toString());
                controller.editKos(IdData);
                controller.showAllKos();
                hideColumn(TableKos,0);
                baris = -1;
            } else {
                JOptionPane.showMessageDialog(null, "Data belum dipilih.");
            }
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        int baris = TableKos.getSelectedRow();
        ControllerDashboard controller;
        controller = new ControllerDashboard(this);
            if (baris != -1) {
                controller.deleteKos(baris);
                controller.showAllKos();
                hideColumn(TableKos,0);
                baris = -1;
            } else {
                JOptionPane.showMessageDialog(null, "Data belum dipilih.");
            }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        lblNAnak.setText("");
        lblNoAnak.setText("");
        lblAngkatan.setText("");
        lblNoKamar.setText("");
        lblNOrtu.setText("");
        lblNoOrtu.setText("");
        lblAsal.setText("");
    }//GEN-LAST:event_btnBatalActionPerformed

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
        String selectedValue = (String) jcbCari.getSelectedItem(); 
        ControllerDashboard controller = new ControllerDashboard(this);
        controller.cariKos(selectedValue); 
        hideColumn(TableKos, 0);
    }//GEN-LAST:event_btnCariActionPerformed

    private void btnTampilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTampilActionPerformed
        ControllerDashboard controller = new ControllerDashboard(this);
        controller.showAllKos();
        hideColumn(TableKos, 0);
    }//GEN-LAST:event_btnTampilActionPerformed
 
    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TableKos;
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnCari;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnTampil;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jcbCari;
    private javax.swing.JTextField lblAngkatan;
    private javax.swing.JTextField lblAsal;
    private javax.swing.JLabel lblLogout;
    private javax.swing.JTextField lblNAnak;
    private javax.swing.JTextField lblNOrtu;
    private javax.swing.JTextField lblNoAnak;
    private javax.swing.JTextField lblNoKamar;
    private javax.swing.JTextField lblNoOrtu;
    // End of variables declaration//GEN-END:variables


    public int getLblAngkatan() {
        int Akt = Integer.parseInt(lblAngkatan.getText());
        return Akt;
    }

    public int getLblNoKamar() {
        int noKamar = Integer.parseInt(lblNoKamar.getText());
        return noKamar;
    }

    public JTable getTableKos() {
        return TableKos;
    }

    public void setTableKos(JTable TableKos) {
        this.TableKos = TableKos;
    }
    

    public void setLblNoKamar(JTextField lblNoKamar) {
        this.lblNoKamar = lblNoKamar;
    }
    

    public void setLblAngkatan(JTextField lblAngkatan) {
        this.lblAngkatan = lblAngkatan;
    }

    public String getLblAsal() {
        return lblAsal.getText();
    }

    public void setLblAsal(JTextField lblAsal) {
        this.lblAsal = lblAsal;
    }

    public JLabel getLblLogout() {
        return lblLogout;
    }

    public void setLblLogout(JLabel lblLogout) {
        this.lblLogout = lblLogout;
    }

    public String getLblNAnak() {
        return lblNAnak.getText();
    }

    public void setLblNAnak(JTextField lblNAnak) {
        this.lblNAnak = lblNAnak;
    }

    public String getLblNOrtu() {
        return lblNOrtu.getText();
    }

    public void setLblNOrtu(JTextField lblNOrtu) {
        this.lblNOrtu = lblNOrtu;
    }

    public String getLblNoAnak() {
        return lblNoAnak.getText();
    }

    public void setLblNoAnak(JTextField lblNoAnak) {
        this.lblNoAnak = lblNoAnak;
    }

    public String getLblNoOrtu() {
        return lblNoOrtu.getText();
    }

    public void setLblNoOrtu(JTextField lblNoOrtu) {
        this.lblNoOrtu = lblNoOrtu;
    }
}
