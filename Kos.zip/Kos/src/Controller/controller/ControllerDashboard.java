package Controller.controller;
import Model.Data.*;
import View.Dashboard;
import java.util.*;
import javax.swing.*;
public class ControllerDashboard implements InterfaceDashboard{
    Dashboard halamanKos; 
    KosDAO daoKos; 
    List<ModelData> daftarData;
    public ControllerDashboard (Dashboard halamanKos){
        this.halamanKos = halamanKos;
        daoKos= new KosDAO();
    }
    public void showAllKos() {
        daftarData = daoKos.getAll();
        ModelTabelKos table = new ModelTabelKos(daftarData);
        halamanKos.getTableKos().setModel(table);
    }
    @Override
    public void insertKos() {
        try {
            ModelData kosBaru = new ModelData();
            String namaAnak = halamanKos.getLblNAnak();
            String noAnak = halamanKos.getLblNoAnak();
            int angkatan = halamanKos.getLblAngkatan();
            int noKamar = halamanKos.getLblNoKamar();
            String namaOrtu = halamanKos.getLblNOrtu();
            String noOrtu = halamanKos.getLblNoOrtu();
            String asal = halamanKos.getLblAsal();
           
            if ("".equals(namaAnak) || "".equals(noAnak) || "".equals(angkatan) || "".equals(noKamar) || "".equals(noOrtu) || "".equals(namaOrtu) || "".equals(asal)) {
                throw new Exception("Data tidak boleh ada yang kosong!"); } 
            if (daoKos.isKamarTerisi(noKamar)) {
                throw new Exception("Kamar sudah terisi!");
            }
            kosBaru.setNamaAnak(namaAnak);
            kosBaru.setNoAnak(noAnak);
            kosBaru.setAngkatan(angkatan);
            kosBaru.setNoKamar(noKamar);
            kosBaru.setNamaOrtu(namaOrtu);
            kosBaru.setNoOrtu(noOrtu);
            kosBaru.setAsal(asal);
            daoKos.insert(kosBaru);   
            JOptionPane.showMessageDialog(null, "Data baru berhasil ditambahkan.");      
            new Dashboard();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    } 
    @Override
    public void editKos(int IdData) {
       try {
            ModelData dataYangMauDiedit = new ModelData();           
            String namaAnak = halamanKos.getLblNAnak();
            String noAnak = halamanKos.getLblNoAnak();
            int angkatan = halamanKos.getLblAngkatan();
            int noKamar = halamanKos.getLblNoKamar();
            String namaOrtu = halamanKos.getLblNOrtu();
            String noOrtu = halamanKos.getLblNoOrtu();
            String asal = halamanKos.getLblAsal();
            
            if ("".equals(namaAnak) || "".equals(noAnak) || "".equals(angkatan) || "".equals(noKamar) || "".equals(noOrtu) || "".equals(namaOrtu) || "".equals(asal)) {
               throw new Exception("Data tidak boleh ada yang kosong!"); 
            } 
            dataYangMauDiedit.setIdData(IdData);
            dataYangMauDiedit.setNamaAnak(namaAnak);
            dataYangMauDiedit.setNoAnak(noAnak);
            dataYangMauDiedit.setAngkatan(angkatan);
            dataYangMauDiedit.setNoKamar(noKamar);
            dataYangMauDiedit.setNamaOrtu(namaOrtu);
            dataYangMauDiedit.setNoOrtu(noOrtu);
            dataYangMauDiedit.setAsal(asal);
            dataYangMauDiedit.setNamaAnak(namaAnak);
            daoKos.update(dataYangMauDiedit);
            
            JOptionPane.showMessageDialog(null, "Data kos berhasil diubah.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage()); 
        }
    }
    @Override
    public void deleteKos(Integer baris) {
        Integer id = (int) halamanKos.getTableKos().getValueAt(baris, 0);
        String namaAnak = halamanKos.getTableKos().getValueAt(baris, 1).toString(); 
        int input = JOptionPane.showConfirmDialog(
                null,
                "Hapus " + namaAnak + "?",
                "Hapus Data Kos",
                JOptionPane.YES_NO_OPTION
        );
        if (input == 0) {
            daoKos.delete(id);
            JOptionPane.showMessageDialog(null, "Berhasil menghapus data.");
            showAllKos(); 
        }  
    }
    
    @Override
    public void cariKos(String noKamar) {
          daftarData = daoKos.cariKos(noKamar); 
        if (daftarData.isEmpty()) {
            JOptionPane.showMessageDialog(halamanKos, "Kamar belum diisi atau tidak ditemukan.", "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            ModelTabelKos table = new ModelTabelKos(daftarData);
            halamanKos.getTableKos().setModel(table);
        }
    }

}