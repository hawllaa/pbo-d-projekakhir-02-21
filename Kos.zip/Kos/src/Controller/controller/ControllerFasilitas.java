package Controller.controller;
import Model.Fasilitas.*;
import View.Fasilitas;
import java.util.*;
import javax.swing.*;
public class ControllerFasilitas {
    Fasilitas halamanFasilitas; 
    FasilitasDAO daoFasilitas; 
    List<ModelFasilitas> daftarFasilitas;
    
    public ControllerFasilitas(Fasilitas halamanFasilitas){
        this.halamanFasilitas = halamanFasilitas;
        daoFasilitas= new FasilitasDAO();
    }
    public void showAllFasilitas() {
        daftarFasilitas = daoFasilitas.getAll();
        ModelTabelFasilitas table = new ModelTabelFasilitas(daftarFasilitas);
        halamanFasilitas.getTabelFasilitas().setModel(table);
    }
    public void insertFasilitas() {
        try {
            ModelFasilitas fasilitasBaru = new ModelFasilitas();
            int noKamar = halamanFasilitas.getLblNoKamar();
            String isian = halamanFasilitas.getLblIsian();
            String fasilitasBersama = halamanFasilitas.getLblFasilitasBersama();
           
            if ("".equals(noKamar) || "".equals(isian) || "".equals(fasilitasBersama)) {
                throw new Exception("Data tidak boleh ada yang kosong!"); 
            } 
            if (daoFasilitas.isKamarTerisi(noKamar)) {
                throw new Exception("Kamar sudah ada data fasilitasnya!");
            }
            fasilitasBaru.setNoKamar(noKamar);
            fasilitasBaru.setIsian(isian);
            fasilitasBaru.setFasilitasBersama(fasilitasBersama);
            daoFasilitas.insert(fasilitasBaru);   
            JOptionPane.showMessageDialog(null, "Data fasilitas baru berhasil ditambahkan.");  
            showAllFasilitas();
            new Fasilitas();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    } 
    public void editFasilitas(int IdFasilitas) {
       try {
            ModelFasilitas fasilitasYangMauDiedit = new ModelFasilitas();           
            int noKamar = halamanFasilitas.getLblNoKamar();
            String isian = halamanFasilitas.getLblIsian();
            String fasilitasBersama = halamanFasilitas.getLblFasilitasBersama();
 
            if ("".equals(noKamar) || "".equals(isian) || "".equals(fasilitasBersama)) {
               throw new Exception("Data tidak boleh ada yang kosong!"); 
            } 
            
            fasilitasYangMauDiedit.setIdFasilitas(IdFasilitas);
            fasilitasYangMauDiedit.setNoKamar(noKamar);
            fasilitasYangMauDiedit.setIsian(isian);
            fasilitasYangMauDiedit.setFasilitasBersama(fasilitasBersama);
            daoFasilitas.update(fasilitasYangMauDiedit);
            
            JOptionPane.showMessageDialog(null, "Data fasilitas berhasil diubah.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage()); 
        }
    }
    public void deleteFasilitas(Integer baris) {
        Integer IdFasilitas = (int) halamanFasilitas.getTabelFasilitas().getValueAt(baris, 0);
        Integer isian  = (int) halamanFasilitas.getTabelFasilitas().getValueAt(baris, 1); 
        int input = JOptionPane.showConfirmDialog(
                null,
                "Hapus " + isian + "?",
                "Hapus Data Fasilitas",
                JOptionPane.YES_NO_OPTION
        );
        if (input == 0) {
            daoFasilitas.delete(IdFasilitas);
            JOptionPane.showMessageDialog(null, "Berhasil menghapus data.");
            showAllFasilitas(); 
        }  
    }
    

}