
package Controller.controller;

public interface InterfaceDashboard {
    public void insertKos();
    public void editKos(int IdData);
    public void deleteKos(Integer baris);
    public void cariKos(String noKamar);
}
