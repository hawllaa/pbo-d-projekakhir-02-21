package Model.Fasilitas;
import java.sql.*;
import java.util.*;

public class FasilitasDAO {
    public void insert(ModelFasilitas fasilitas) {
       try {
            String query = "INSERT INTO fasilitas(noKamar, isian, fasilitasBersama) VALUES (?, ?, ?);";
            PreparedStatement statement;
            statement = Conn.Connect().prepareStatement(query);
            statement.setInt(1, fasilitas.getNoKamar());
            statement.setString(2, fasilitas.getIsian());
            statement.setString(3, fasilitas.getFasilitasBersama());
            statement.executeUpdate();
            statement.close();        
        } catch (SQLException e) {
            System.out.println("Input Failed: " + e.getLocalizedMessage());
        } 
    }

    public void update(ModelFasilitas fasilitas) {
        try {
            String query = "UPDATE fasilitas SET noKamar=?, isian=?, fasilitasBersama=? WHERE IdFasilitas=?;";
            PreparedStatement statement;
            statement = Conn.Connect().prepareStatement(query);
            statement.setInt(1, fasilitas.getNoKamar());
            statement.setString(2, fasilitas.getIsian());
            statement.setString(3, fasilitas.getFasilitasBersama());
            statement.setInt(4, fasilitas.getIdFasilitas());
            statement.executeUpdate();
            statement.close();
            
        } catch (SQLException e) {
            System.out.println("update Failed! (" + e.getMessage() + ")");
        }
    }

    public void delete(int IdFasilitas) {
        try {
            String query = "DELETE FROM fasilitas WHERE IdFasilitas=?;";
            PreparedStatement statement;
            statement = Conn.Connect().prepareStatement(query);
            statement.setInt(1, IdFasilitas);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getLocalizedMessage()); 
        }
    }

    public List<ModelFasilitas> getAll() {
         List<ModelFasilitas> listFasilitas = null;
         Connection conn = Conn.Connect();

        try {
            listFasilitas = new ArrayList<>();
            String query = "SELECT * FROM fasilitas";
            Statement statement = Conn.Connect().createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            
            while (resultSet.next()) {
              
                ModelFasilitas fst = new ModelFasilitas();
                fst.setIdFasilitas(resultSet.getInt("IdFasilitas"));
                fst.setNoKamar(resultSet.getInt("noKamar"));
                fst.setIsian(resultSet.getString("isian"));
                fst.setFasilitasBersama(resultSet.getString("fasilitasBersama"));
                
                listFasilitas.add(fst);
            }
            
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return listFasilitas;
    }
    
    public boolean isKamarTerisi(int noKamar) {
    boolean terisi = false;
    Connection conn = Conn.Connect(); 
    try {
        String query = "SELECT COUNT(*) FROM fasilitas WHERE noKamar = ?"; 
        PreparedStatement statement = conn.prepareStatement(query);
        statement.setInt(1, noKamar);
        ResultSet resultSet = statement.executeQuery();
        
        if (resultSet.next()) {
            terisi = resultSet.getInt(1) > 0; 
        }      
        statement.close();
    } catch (SQLException e) {
        System.out.println("Error: " + e.getLocalizedMessage());
    } 
    return terisi;
    }
    
}
