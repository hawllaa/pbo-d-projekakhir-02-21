package Model.Fasilitas;
import java.util.*;
import javax.swing.table.*;

public class ModelTabelFasilitas extends AbstractTableModel {
    List<ModelFasilitas> daftarFasilitas;
    String kolom[] = {"ID Fasilitas", "No Kamar", "Isian Kamar", "Fasilitas Bersama"};

    public ModelTabelFasilitas(List<ModelFasilitas> daftarFasilitas) {
        this.daftarFasilitas = daftarFasilitas;
    }

    @Override
    public int getRowCount() {
        return daftarFasilitas.size();
    }

    @Override
    public int getColumnCount() {
        return kolom.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0 :
                return daftarFasilitas.get(rowIndex).getIdFasilitas();
            case 1:
                return daftarFasilitas.get(rowIndex).getNoKamar();
            case 2:
                return daftarFasilitas.get(rowIndex).getIsian();
            case 3:
                return daftarFasilitas.get(rowIndex).getFasilitasBersama();
            default:
                return null;
        }
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return kolom[columnIndex];
    }
}