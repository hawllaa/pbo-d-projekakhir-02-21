package Model.Fasilitas;
public class ModelFasilitas {
    private int IdFasilitas;
    private int noKamar;
    private String isian;
    private String fasilitasBersama;

    public int getIdFasilitas() {
        return IdFasilitas;
    }

    public void setIdFasilitas(int IdFasilitas) {
        this.IdFasilitas = IdFasilitas;
    }

    public int getNoKamar() {
        return noKamar;
    }

    public void setNoKamar(int noKamar) {
        this.noKamar = noKamar;
    }

    public String getIsian() {
        return isian;
    }

    public void setIsian(String isian) {
        this.isian = isian;
    }

    public String getFasilitasBersama() {
        return fasilitasBersama;
    }

    public void setFasilitasBersama(String fasilitasBersama) {
        this.fasilitasBersama = fasilitasBersama;
    }
    
}
